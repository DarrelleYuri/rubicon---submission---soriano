package com.soriano.draw.service;

import com.soriano.drawfx.model.Shape;
import com.soriano.drawfx.service.RendererService;
import java.awt.*;

public class EllipseRendererService implements RendererService {
    @Override
    public void render(Graphics g, Shape shape, boolean xor) {
        if (xor) {
            g.setXORMode(Color.white);
        }
        g.setColor(shape.getColor());

        Point start = shape.getLocation();
        Point end = shape.getEnd();

        int x_axis = Math.min(start.x, end.x);
        int y_axis = Math.min(start.y, end.y);
        int width = Math.abs(start.x - end.x);
        int height = Math.abs(start.y - end.y);

        g.drawOval(x_axis, y_axis, width, height);

        if (xor) {
            g.setPaintMode();
        }
    }
}