package com.soriano.draw;

import com.soriano.draw.service.DrawingAppService;
import com.soriano.draw.view.DrawingFrame;
import com.soriano.drawfx.service.AppService;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        AppService appService = new DrawingAppService();
        DrawingFrame drawingFrame = new DrawingFrame(appService);
        drawingFrame.setVisible(true);
        drawingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        drawingFrame.setSize(500,500);
    }
}