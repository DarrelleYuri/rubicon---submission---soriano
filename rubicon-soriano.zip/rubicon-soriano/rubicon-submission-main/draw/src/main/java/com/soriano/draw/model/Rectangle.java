package com.soriano.draw.model;

import com.soriano.draw.service.RectangleRendererService;
import com.soriano.drawfx.model.Shape;
import java.awt.*;

public class Rectangle extends Shape {

    public Rectangle(Point start, Point end) {
        super(start);
        this.setColor(Color.BLUE);
        this.setEnd(end);
        this.setRendererService(new RectangleRendererService());
    }
}