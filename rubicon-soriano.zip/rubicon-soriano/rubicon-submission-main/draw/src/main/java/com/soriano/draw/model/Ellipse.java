package com.soriano.draw.model;

import com.soriano.draw.service.EllipseRendererService;
import com.soriano.drawfx.model.Shape;
import java.awt.*;

public class Ellipse extends Shape {

    public Ellipse(Point start, Point end) {
        super(start);
        this.setColor(Color.GREEN);
        this.setEnd(end);
        this.setRendererService(new EllipseRendererService());
    }
}