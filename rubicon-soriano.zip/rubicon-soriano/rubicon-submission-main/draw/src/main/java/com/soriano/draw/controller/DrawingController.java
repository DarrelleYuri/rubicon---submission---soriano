package com.soriano.draw.controller;

import com.soriano.draw.model.Ellipse;
import com.soriano.draw.model.Line;
import com.soriano.draw.model.Rectangle;
import com.soriano.drawfx.DrawMode;
import com.soriano.drawfx.ShapeMode;
import com.soriano.draw.view.DrawingView;
import com.soriano.drawfx.service.AppService;
import com.soriano.drawfx.model.Shape;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class DrawingController implements MouseListener, MouseMotionListener {
    private Point end;
    final private DrawingView drawingView;
    Shape currentShape;
    AppService appService;

    public DrawingController(AppService appService, DrawingView drawingView) {
        this.appService = appService;
        this.drawingView = drawingView;
        drawingView.addMouseListener(this);
        drawingView.addMouseMotionListener(this);
        appService.setDrawMode(DrawMode.Idle);
        // appService.setShapeMode(ShapeMode.Rectangle);
        // appService.setShapeMode(ShapeMode.Line);
         appService.setShapeMode(ShapeMode.Ellipse);

    }
    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        Point start;
        if (appService.getDrawMode() == DrawMode.Idle) {
            start = e.getPoint();
            ShapeMode currentMode = appService.getShapeMode();

            if (currentMode == ShapeMode.Line) {
                currentShape = new Line(start, start);
            }

            else if (currentMode == ShapeMode.Rectangle) {
                currentShape = new Rectangle(start, start);
            }
            else if (currentMode == ShapeMode.Ellipse) {
                currentShape = new Ellipse(start, start);
            }

            if (currentShape != null) {
                appService.setDrawMode(DrawMode.MousePressed);
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (appService.getDrawMode() == DrawMode.MousePressed) {
            if (currentShape != null) {
                appService.create(currentShape);
                currentShape = null;
                appService.setDrawMode(DrawMode.Idle);
                drawingView.repaint();
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (appService.getDrawMode() == DrawMode.MousePressed) {
            if (currentShape != null) {
                end = e.getPoint();

                currentShape.getRendererService().render(drawingView.getGraphics(), currentShape, true);

                appService.scale(currentShape, end);

                currentShape.getRendererService().render(drawingView.getGraphics(), currentShape, true);
            }
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
