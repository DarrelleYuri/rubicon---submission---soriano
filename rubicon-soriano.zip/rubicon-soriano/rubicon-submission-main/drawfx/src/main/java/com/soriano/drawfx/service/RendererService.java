package com.soriano.drawfx.service;

import com.soriano.drawfx.model.Shape;
import java.awt.*;

public interface RendererService {
    void render(Graphics g, Shape shape, boolean xor);
}
