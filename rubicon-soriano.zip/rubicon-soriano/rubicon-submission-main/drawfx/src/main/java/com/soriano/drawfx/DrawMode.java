package com.soriano.drawfx;

public enum DrawMode {
    Idle,
    MousePressed,
    MouseReleased,
}
