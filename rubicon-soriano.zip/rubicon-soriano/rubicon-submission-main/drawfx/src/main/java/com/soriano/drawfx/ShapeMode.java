package com.soriano.drawfx;

public enum ShapeMode {
    Line,
    Rectangle,
    Ellipse,
}
