package com.soriano.drawfx.service;

import com.soriano.drawfx.model.Shape;

import java.awt.*;

public final class MoverService {
    public void  move(Shape shape, Point newLoc){
        shape.setLocation( newLoc);
     }
}
