package com.soriano.drawfx.service;

import com.soriano.drawfx.model.Shape;

import java.awt.*;

public final class  ScalerService {
    void scale(Shape shape, Point newEnd){
        shape.setEnd(newEnd);
    }
}
